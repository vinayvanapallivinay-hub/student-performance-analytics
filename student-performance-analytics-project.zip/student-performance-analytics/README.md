# Student Performance Analytics System

A beginner-friendly Python data-analysis project for the Python with AI assignment. It uses **Python, NumPy and Pandas** to analyse student marks and attendance.

## Features
- Loads 20 student records from `students.csv` into a Pandas DataFrame.
- Calculates total and average marks for each student.
- Assigns grades using the rule below.
- Identifies pass/fail students.
- Reports class statistics, subject-wise averages, department-wise averages and top five students.
- Summarises attendance and flags attendance below 75%.
- Saves detailed results to `analysis_results.csv`.

## Grading rule
- A+: average >= 90
- A: average >= 80 and < 90
- B: average >= 70 and < 80
- C: average >= 60 and < 70
- D: average >= 50 and < 60
- F: average < 50

**Pass rule:** a student passes only when they score at least 40 in every listed subject. This is the rule chosen for this sample project; change it if your instructor specifies another rule.

## Requirements
- Python 3.9 or newer
- pip

## Run on Windows (PowerShell or Command Prompt)
1. Install Python from https://www.python.org/downloads/ if it is not installed. During installation, select **Add Python to PATH**.
2. Open this folder in VS Code, or open a terminal and move into the project folder.
3. Install libraries:

   ```bash
   python -m pip install -r requirements.txt
   ```

4. Run:

   ```bash
   python main.py
   ```

   If `python` is not recognised, try `py main.py` and `py -m pip install -r requirements.txt`.

5. The program prints the report and creates `analysis_results.csv` in this folder.

## Dataset columns
`Student_ID`, `Name`, `Department`, `Python`, `AI`, `Statistics`, `Data_Analysis`, `Attendance`.

Subject marks are out of 100; attendance is a percentage. The CSV contains fictional sample data for demonstration, not real student records.

## Project structure
```text
student-performance-analytics/
├── main.py
├── students.csv
├── requirements.txt
├── README.md
├── .gitignore
└── docs/
    └── Project_Documentation.md
```

## GitHub upload (using GitHub website)
1. Sign in at https://github.com/.
2. Click **+** → **New repository**.
3. Name it `student-performance-analytics`.
4. Choose **Public** if your trainer requires a public repository (otherwise follow the trainer's instruction).
5. Create the repository.
6. Use **Add file** → **Upload files** to upload the project files and `docs` folder, then commit the changes. Alternatively, use Git commands as described in the documentation.
7. Open the repository and check that `main.py`, `students.csv`, `requirements.txt`, `README.md`, `.gitignore`, and `docs/Project_Documentation.md` are visible.
8. Copy the repository URL and paste it into the Google Form provided by EWB Courses.

## Notes
- `analysis_results.csv` is generated when the program runs; it is excluded from GitHub because it can be regenerated.
- The assignment PDF lists a submission deadline of **15 October 2026**. If you have not submitted yet, contact your trainer to confirm whether late submission is accepted.
