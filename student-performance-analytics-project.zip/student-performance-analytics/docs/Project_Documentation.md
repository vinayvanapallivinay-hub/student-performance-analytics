# Project Documentation — Student Performance Analytics System

## 1. Project Title and Student Details
**Project Title:** Student Performance Analytics System  
**Student Name:** Vinay (edit if your certificate/college records require your full name)  
**Course:** Python with AI  
**Technologies:** Python, NumPy, Pandas

## 2. Objective
The objective is to analyse student marks and attendance using Python. The program summarises each student's performance and helps identify strong subjects, students who need support, and the highest-performing students.

## 3. Technologies Used
- **Python:** program logic, conditions, loops, functions and file paths.
- **Pandas:** reads the CSV file into a DataFrame, calculates summaries, groups data and exports results.
- **NumPy:** applies a vectorised condition to calculate pass/fail status.
- **CSV:** stores the sample dataset.

## 4. Dataset Description
The included `students.csv` contains 20 fictional student records. Columns are Student_ID, Name, Department, Python, AI, Statistics, Data_Analysis and Attendance. Each subject mark is out of 100; attendance is a percentage. The dataset is provided for learning and does not represent real students.

## 5. Implementation
1. Import NumPy and Pandas and define the dataset path and subject columns.
2. Read `students.csv` using `pandas.read_csv()`.
3. Check that the required columns exist and that the dataset is not empty or missing required values.
4. Calculate total marks by adding the four subject marks.
5. Calculate average marks and assign a grade using the `assign_grade()` function.
6. Use NumPy's `where()` and a condition across all subject columns to mark each student PASS or FAIL.
7. Calculate class-level statistics, subject averages, department averages and attendance summary.
8. Sort students by average marks and display the top five.
9. Export the analysed records to `analysis_results.csv`.

## 6. Grading and Pass/Fail Rules
- A+: average is 90 or above.
- A: average is 80 to below 90.
- B: average is 70 to below 80.
- C: average is 60 to below 70.
- D: average is 50 to below 60.
- F: average is below 50.

A student passes only if every subject mark is at least 40. This is the sample rule selected for this project; use your trainer's rule if it differs.

## 7. Key Features
- CSV data loading and basic validation.
- Student-wise totals, averages, grades and pass/fail status.
- Highest, lowest and class average.
- Subject-wise and department-wise analysis.
- Top-five student list.
- Attendance summary and below-75% count.
- Export of complete results to a new CSV file.

## 8. Output / Screenshots
Run `python main.py` and capture a screenshot of the terminal output. If your instructor expects screenshots, add genuine screenshots to this folder and update this section. Do not insert a screenshot that you have not actually captured.

Suggested screenshots:
1. The terminal showing the overall class summary.
2. The student-wise results table.
3. The subject-wise averages and top-five list.
4. The generated `analysis_results.csv` opened in a spreadsheet program.

## 9. Final Outcome
The program processes the sample student dataset and produces an understandable performance report. It demonstrates how Python functions and conditions can be combined with NumPy and Pandas for basic data analysis.

## 10. Challenges and Learning
Possible learning points after testing the program:
- Organising tabular data in a CSV file.
- Loading and checking data with Pandas.
- Using functions to keep calculations reusable.
- Using conditions to assign grades and results.
- Calculating averages and grouping data by subject or department.
- Running a Python program and publishing project files on GitHub.

Edit this section to describe the actual errors you encountered and how you solved them.

## 11. GitHub Repository
**Repository URL:** Add your actual GitHub repository URL here after uploading the project.

## 12. How to Run
1. Install Python 3.9 or newer.
2. Open a terminal in the project folder.
3. Install dependencies with `python -m pip install -r requirements.txt`.
4. Run with `python main.py`.
5. Review the terminal report and the generated `analysis_results.csv`.

## 13. Declaration / Academic Integrity
Review every function and calculation, test the project yourself, and be prepared to explain it to your trainer. This project uses fictional sample data; make sure the final code and documentation reflect your own understanding and any changes required by your course.
