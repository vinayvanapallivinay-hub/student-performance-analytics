"""
Student Performance Analytics System
A beginner-friendly Python project using Pandas and NumPy.
Run: python main.py
"""
from pathlib import Path
import numpy as np
import pandas as pd

DATA_FILE = Path(__file__).resolve().parent / "students.csv"
SUBJECTS = ["Python", "AI", "Statistics", "Data_Analysis"]
PASS_MARK = 40  # A student must score at least 40 in every subject to pass.

def assign_grade(average):
    """Return a grade based on the student's average mark."""
    if average >= 90:
        return "A+"
    elif average >= 80:
        return "A"
    elif average >= 70:
        return "B"
    elif average >= 60:
        return "C"
    elif average >= 50:
        return "D"
    else:
        return "F"

def load_data(file_path=DATA_FILE):
    """Load student records and validate the required columns."""
    df = pd.read_csv(file_path)
    required = ["Student_ID", "Name", "Department", *SUBJECTS, "Attendance"]
    missing = [column for column in required if column not in df.columns]
    if missing:
        raise ValueError(f"Dataset is missing required columns: {', '.join(missing)}")
    if df.empty:
        raise ValueError("The student dataset is empty.")
    if df[required].isnull().any().any():
        raise ValueError("The dataset contains blank required values. Please correct students.csv.")
    return df

def analyse_students(df):
    """Add totals, averages, grades and pass/fail results."""
    result = df.copy()
    result["Total_Marks"] = result[SUBJECTS].sum(axis=1)
    result["Average_Marks"] = result[SUBJECTS].mean(axis=1).round(2)
    result["Grade"] = result["Average_Marks"].apply(assign_grade)
    # A student passes only if all subject marks are at least PASS_MARK.
    result["Result"] = np.where((result[SUBJECTS] >= PASS_MARK).all(axis=1), "PASS", "FAIL")
    return result

def print_report(df):
    """Print the main performance report to the terminal."""
    analysed = analyse_students(df)
    print("\n" + "=" * 78)
    print("             STUDENT PERFORMANCE ANALYTICS SYSTEM")
    print("=" * 78)
    print(f"Total students: {len(analysed)}")
    print(f"Passed: {(analysed['Result'] == 'PASS').sum()}")
    print(f"Failed: {(analysed['Result'] == 'FAIL').sum()}")
    print(f"Pass percentage: {(analysed['Result'].eq('PASS').mean() * 100):.2f}%")
    print(f"Overall class average: {analysed['Average_Marks'].mean():.2f}/100")
    print(f"Highest student average: {analysed['Average_Marks'].max():.2f}")
    print(f"Lowest student average: {analysed['Average_Marks'].min():.2f}")

    print("\nSTUDENT-WISE RESULTS")
    columns = ["Student_ID", "Name", "Department", "Total_Marks", "Average_Marks", "Grade", "Result"]
    print(analysed[columns].to_string(index=False))

    print("\nSUBJECT-WISE AVERAGE")
    subject_averages = analysed[SUBJECTS].mean().sort_values(ascending=False)
    for subject, average in subject_averages.items():
        print(f"{subject.replace('_', ' '):<18}: {average:.2f}/100")
    print(f"Best-performing subject: {subject_averages.index[0].replace('_', ' ')}")

    print("\nTOP 5 STUDENTS")
    top_five = analysed.sort_values(
        by=["Average_Marks", "Name"], ascending=[False, True]
    ).head(5)
    print(top_five[["Student_ID", "Name", "Average_Marks", "Grade"]].to_string(index=False))

    print("\nDEPARTMENT-WISE AVERAGE")
    department_averages = analysed.groupby("Department")["Average_Marks"].mean().sort_values(ascending=False)
    for department, average in department_averages.items():
        print(f"{department:<10}: {average:.2f}/100")

    print("\nATTENDANCE SUMMARY")
    print(f"Average attendance: {analysed['Attendance'].mean():.2f}%")
    print(f"Students with attendance below 75%: {(analysed['Attendance'] < 75).sum()}")

    output_file = Path(__file__).resolve().parent / "analysis_results.csv"
    analysed.to_csv(output_file, index=False)
    print(f"\nDetailed results saved to: {output_file.name}")
    print("=" * 78)

def main():
    try:
        data = load_data()
        print_report(data)
    except FileNotFoundError:
        print("Error: students.csv was not found. Keep it in the same folder as main.py.")
    except (ValueError, pd.errors.ParserError) as error:
        print(f"Could not process the dataset: {error}")

if __name__ == "__main__":
    main()
